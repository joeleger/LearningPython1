from setuptools import setup

setup(
    name='checker',
    version='1.0',
    description='Function Annotation authentication',
    author='Joseph Leger',
    author_email='joeleger59@gmail.com',
    url='abc.com',
    py_modules=['checker'],
)

